const mysql = require('mysql');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const db = mysql.createConnection({
    host:process.env.DATABSE_HOST,
    user:process.env.DATABSE_USER,
    password:process.env.DATABSE_PASSWORD,
    database:process.env.DATABSE
});

exports.register=(req,res) => {
    console.log(req.body.name);
     
    const{name, password, ConfirmPassword}=req.body;

    console.log("here",name,password,ConfirmPassword);

    var First_SQL_Query = "SELECT user_email FROM user_login WHERE user_email = ?";

    db.query(First_SQL_Query, [name], async(error, results)=>{
        if(error){
            console.log(error);
        }
        
        //if is finding if user already exists
        if(results.length>0){
            return res.render('register', {
                message : "user already exists"
            });
        }else if(password !== ConfirmPassword){
            return res.render('register', {
                message : "password does not match"
            });
        }

        let hashpassword = await bcrypt.hash(password,8);
        console.log(hashpassword);

        db.query('INSERT INTO user_login SET ?', {user_email:name , user_password:hashpassword}, (error , results)=>{
            console.log(results);
            if(error){
                console.log(error);
            }
            else{
                return res.render('register', {
                    message : "user registerd"
                });
            }
        })

    });



}